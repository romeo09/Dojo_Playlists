class AddDefaultValueToTimeAdded < ActiveRecord::Migration
  def change
  end
end
